<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "form_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form data
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = htmlspecialchars($_POST['name']);
    $movie = htmlspecialchars($_POST['movie']);
    $degree = htmlspecialchars($_POST['degree']);
    $gender = htmlspecialchars($_POST['gender']);
    $units = isset($_POST['units']) ? implode(", ", $_POST['units']) : "None";

    // Insert data into the database
    $sql = "INSERT INTO submissions (name, movie, degree, gender, units) 
            VALUES ('$name', '$movie', '$degree', '$gender', '$units')";

    if ($conn->query($sql) === TRUE) {
        echo "<p style='color: green; text-align: center;'>Data saved successfully!</p>";
    } else {
        echo "<p style='color: red; text-align: center;'>Error: " . $conn->error . "</p>";
    }

    // Display submitted data
    echo "<h1 style='background-color: blue; color: white; text-align: center;'>PostForm Submitted</h1>";
    echo "<p>Hello, <strong>$name</strong></p>";
    echo "<p>You like the movie <strong>$movie</strong></p>";
    echo "<p>You are enrolled in <strong>$degree</strong></p>";
    echo "<p>Your gender is <strong>$gender</strong></p>";
    echo "<p>Your favorite subject(s) are: <strong>$units</strong></p>";
} else {
    echo "<p>No data submitted!</p>";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PostForm Submitted</title>
    <style>
        h1 {
            background-color: blue;
            color: white;
            font-size: 2em;
            text-align: center;
            padding: 10px;
        }
    </style>
</head>
<body>
</body>
</html>
