<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PostForm.php</title>
    <style>
        h1 {
            background-color: blue;
            color: white;
            font-size: 2em;
            padding: 10px;
        }
    </style>
</head>
<body>
    <h1>PostForm.php</h1>

    <form action="postform_submitted.php" method="POST">
        <label for="name">My name is:</label><br>
        <input type="text" id="name" name="name" required><br><br>

        <label for="movie">My favorite movie is:</label><br>
        <input type="text" id="movie" name="movie" required><br><br>

        <label for="degree">My degree is:</label><br>
        <select id="degree" name="degree" required>
            <option value="Bachelor">Bachelor</option>
            <option value="Master">Master</option>
            <option value="PhD">PhD</option>
        </select><br><br>

        <label for="gender">Gender:</label><br>
        <select id="gender" name="gender" required>
            <option value="Female">Female</option>
            <option value="Male">Male</option>
        </select><br><br>

        <label for="units">My favorite unit(s):</label><br>
        <select id="units" name="units[]" multiple required>
            <option value="Math">Math</option>
            <option value="Science">Science</option>
            <option value="History">History</option>
        </select><br><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
