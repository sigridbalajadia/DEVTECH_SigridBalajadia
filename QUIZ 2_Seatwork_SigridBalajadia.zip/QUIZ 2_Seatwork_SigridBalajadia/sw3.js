var number = 10; 
if (number % 2 === 0) {
    console.log("it is even number");
    } else {
        console.log("It is odd");
    }