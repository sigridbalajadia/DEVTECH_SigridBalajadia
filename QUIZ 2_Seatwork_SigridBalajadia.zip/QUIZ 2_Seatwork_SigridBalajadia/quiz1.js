var number = 9; 
if (number % 3 === 0) {
    console.log("The number is odd");
    } else 
        console.log("The number is even");
{

}