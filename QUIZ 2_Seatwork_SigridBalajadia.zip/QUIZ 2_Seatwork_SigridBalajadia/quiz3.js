let number = 15; 

if (number > 0) {
    console.log("The number is positive."); 
} else if (number < 0) {
    console.log("The number is negative.");
} else {
    console.log("The number is zero.");
}